grammar masmenos;
root : expr EOF ;
expr : <assoc=right> expr '^' expr
    | expr MAS expr 
    | expr MEN expr
    | expr MULT expr
    | expr DIV expr
    | NUM
    ;

NUM : [0-9]+ ;
MAS : '+' ;
MEN : '-' ;
MULT : '*' ;
DIV : '/' ;
POT : '^' ;
WS : [ \n]+ -> skip ;