# Generated from masmenos.g by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .masmenosParser import masmenosParser
else:
    from masmenosParser import masmenosParser

# This class defines a complete generic visitor for a parse tree produced by masmenosParser.

class masmenosVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by masmenosParser#root.
    def visitRoot(self, ctx:masmenosParser.RootContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by masmenosParser#expr.
    def visitExpr(self, ctx:masmenosParser.ExprContext):
        return self.visitChildren(ctx)



del masmenosParser