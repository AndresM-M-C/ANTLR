// Generated from /home/andres7/Documentos/resta/res.g by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link resParser}.
 */
public interface resListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link resParser#root}.
	 * @param ctx the parse tree
	 */
	void enterRoot(resParser.RootContext ctx);
	/**
	 * Exit a parse tree produced by {@link resParser#root}.
	 * @param ctx the parse tree
	 */
	void exitRoot(resParser.RootContext ctx);
	/**
	 * Enter a parse tree produced by {@link resParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(resParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link resParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(resParser.ExprContext ctx);
}