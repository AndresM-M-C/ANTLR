# Generated from res.g by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .resParser import resParser
else:
    from resParser import resParser

# This class defines a complete generic visitor for a parse tree produced by resParser.

class resVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by resParser#root.
    def visitRoot(self, ctx:resParser.RootContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by resParser#expr.
    def visitExpr(self, ctx:resParser.ExprContext):
        return self.visitChildren(ctx)



del resParser