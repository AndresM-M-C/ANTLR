grammar res;
root : expr EOF ;
expr :  expr RES expr
    | NUM
    ;
NUM : [0-9]+ ;
RES : '-' ;
WS : [ \n]+ -> skip ;